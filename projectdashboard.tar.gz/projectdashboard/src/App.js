import Header from "./komponen/Header";
import Dropdown from "./komponen/Dropdown";
import Search from "./komponen/Search";
import TokenCoin from "./komponen/TokenCoin";
import "./App.css";
import Candlestick from "./komponen/Candlestick";
import Dashboard from "./komponen/Dashboard";
import React from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";

const App = () => {
  return (
    <Router>
      <Switch>
        <Route exact path="/header">
          <Header />
        </Route>
        <Route exact path="/">
          <Search />
        </Route>
        <Route exact path="/">
          <TokenCoin />
        </Route>
        <Route exact path="/">
          <Dashboard />
        </Route>
        <Route exact path="/">
          <Candlestick />
        </Route>
      </Switch>
    </Router>
  );
};

export default App;
