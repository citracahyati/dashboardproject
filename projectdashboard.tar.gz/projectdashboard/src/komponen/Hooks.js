import React, { Component } from 'react';

function Hooks() {
  return (state = {
    subscribe: false,
    like: 0,
    dislike: 0,
  });

  handleSubscribe = () => {
    setState({
      subscribe: state.subsscribe,
    });
  };

  handleLike = () => {};
}

export default Hooks;
